using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using System;
using Cinemachine;
using UnityEngine.InputSystem;


public class LevelManager : MonoBehaviour
{

    [SerializeField] TMP_Text coinTracker;
    [SerializeField] TMP_Text livesTracker;
    [SerializeField] PlayerController PlayerPrefab;
    [SerializeField] Transform StartPos ;
    [SerializeField] CinemachineVirtualCamera cinemachineCamera;
    [SerializeField] CameraController cameraController;
    [SerializeField] Camera levelCamera;
    [SerializeField] float PlayerSpawnerSpacerAmount = 1.5f;

    [SerializeField] bool playerOneUsesKeyboard = true;

    public int NumberOfPlayers = 1;
    public int remainingLives = 15;


    List <PlayerController> players = new List<PlayerController> ();

    int TotalCoins = 0;
    Vector3 screenBounds;
    // Start is called before the first frame update
    void Start()
    {
        NumberOfPlayers = 1;
        for (int i = 0; i < NumberOfPlayers; i++)
        {
            PlayerController newPlayer = Instantiate(PlayerPrefab);
            Vector3 spawnPos = StartPos.position;
            spawnPos.x += (PlayerSpawnerSpacerAmount * i);
            newPlayer.transform.position = spawnPos;
            newPlayer.initPlayer(livesTracker, StartPos, this);
            newPlayer.name = "Player " + i.ToString();
            if (i == 0)
            {
                if (!playerOneUsesKeyboard && Gamepad.all.Count > 0)
                {

                    newPlayer.getStateMachine().playerInput.SwitchCurrentControlScheme(Gamepad.all[0]);
                }
            }
         
            else if (i < Gamepad.all.Count)
            { 
             
                newPlayer.getStateMachine().playerInput.SwitchCurrentControlScheme(Gamepad.all[i]);
            }
            else
            {
                NumberOfPlayers = i + 1;
                break;
            }


            players.Add(newPlayer);
        }
        cameraController.playerMachine = players[0].getStateMachine();
        cinemachineCamera.m_Follow = players[0].transform;
        //Follow player one always
        Debug.Log("Cinemachine is going to follow player " + cinemachineCamera.m_Follow.ToString());
        Debug.Log("Finished init of level");


    }

    // Update is called once per frame
    void Update()
    {
        /*
        foreach (PlayerController player in players)
        {
         
           if (player == players[0]) { continue; }
            //First player determines position of camera, all other players are restricted by it
            Vector2 newPosition = player.transform.position;
            newPosition.x = Mathf.Clamp(newPosition.x, screenBounds.x, -screenBounds.x);
            newPosition.y = Mathf.Clamp(newPosition.y, screenBounds.y, -screenBounds.y);
            player.transform.position = newPosition;
        } */ 

    }

    public void AddCoins(int amount = 1)
    {
        TotalCoins += amount;
        if (TotalCoins < 10)
        {
            coinTracker.text = "0" + TotalCoins.ToString();
        }
        else
        {
            coinTracker.text = TotalCoins.ToString();
        }
    }

    public void changeLives(int amount)
    {
        remainingLives += amount;
        livesTracker.text = "Lives: " + remainingLives.ToString();
        if (remainingLives < 0)
        {
            Debug.Log("You lose!");
            Time.timeScale = 0;
        }
    }


}
